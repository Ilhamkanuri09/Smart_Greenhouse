@extends('layouts.app')

@section('title', 'Set Parameter Threshold - Greenhouse')

@section('content')
<div class="container" style="max-width: 900px;">
    @if(session('success'))
    <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm rounded-3 mb-4" role="alert">
        <div class="d-flex align-items-center">
            <i class="fa-solid fa-circle-check fa-lg me-2"></i>
            <div>{{ session('success') }}</div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    <!-- BILAH FILTER PILIHAN PERANGKAT (DROPDOWN) -->
    <div class="card card-custom p-3 bg-white shadow-sm mb-4 border-start border-success border-5">
        <div class="row align-items-center">
            <div class="col-md-6 mb-2 mb-md-0">
                <h5 class="fw-bold mb-0 text-dark">
                    <i class="fa-solid fa-microchip text-success me-2"></i>Pilih Perangkat:
                </h5>
                <small class="text-muted">Atur ambang batas otomatisasi khusus untuk modul pilihan.</small>
            </div>
            <div class="col-md-6">
                <form action="{{ route('threshold.index') }}" method="GET" id="filter-threshold-device-form">
                    <select name="device_code" class="form-select fw-bold border-success text-success" onchange="document.getElementById('filter-threshold-device-form').submit()">
                        @forelse($devices as $dev)
                            <option value="{{ $dev->device_code }}" {{ $selectedDevice && $selectedDevice->device_code == $dev->device_code ? 'selected' : '' }}>
                                🌿 {{ $dev->nama_greenhouse }} ({{ $dev->device_code }})
                            </option>
                        @empty
                            <option value="">Belum Ada Perangkat Terdaftar</option>
                        @endforelse
                    </select>
                </form>
            </div>
        </div>
    </div>

    @if($selectedDevice)
    <div class="card card-custom p-4 mb-5 bg-white shadow-sm">
        <div class="d-flex align-items-center mb-4">
            <div class="bg-success text-white p-3 rounded-3 me-3">
                <i class="fa-solid fa-gears fa-2x"></i>
            </div>
            <div>
                <h4 class="mb-0 fw-bold text-dark">Konfigurasi Ambang Batas ({{ $selectedDevice->device_code }})</h4>
                <p class="text-muted mb-0">Ubah parameter logika otomatisasi alat untuk <strong>{{ $selectedDevice->nama_greenhouse }}</strong> secara dinamis.</p>
            </div>
        </div>

        <form action="{{ route('threshold.update') }}" method="POST">
            @csrf
            
            <!-- HIDDEN INPUT DEVICE ID (SANGAT PENTING DIBUTUHKAN CONTROLLER) -->
            <input type="hidden" name="device_id" value="{{ $selectedDevice->id }}">

            <!-- KIPAS EXHAUST -->
            <div class="mb-4">
                <div class="text-danger fw-bold border-bottom pb-2 mb-3"><i class="fa-solid fa-wind me-2"></i>Kipas Exhaust (Suhu)</div>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label text-secondary small fw-semibold">Suhu Aktif Kipas (ON)</label>
                        <div class="input-group">
                            <input type="number" step="0.1" name="batas_suhu_on" class="form-control" value="{{ $threshold->batas_suhu_on }}" required>
                            <span class="input-group-text">°C</span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-secondary small fw-semibold">Suhu Mati Kipas (OFF)</label>
                        <div class="input-group">
                            <input type="number" step="0.1" name="batas_suhu_off" class="form-control" value="{{ $threshold->batas_suhu_off }}" required>
                            <span class="input-group-text">°C</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- POMPA AIR -->
            <div class="mb-4">
                <div class="text-success fw-bold border-bottom pb-2 mb-3"><i class="fa-solid fa-droplet me-2"></i>Pompa Air (Kelembaban Tanah)</div>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label text-secondary small fw-semibold">Batas Tanah Hidup Pompa (ON)</label>
                        <div class="input-group">
                            <input type="number" name="batas_tanah_on" class="form-control" value="{{ $threshold->batas_tanah_on }}" min="0" max="100" required>
                            <span class="input-group-text">%</span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-secondary small fw-semibold">Batas Tanah Mati Pompa (OFF)</label>
                        <div class="input-group">
                            <input type="number" name="batas_tanah_off" class="form-control" value="{{ $threshold->batas_tanah_off }}" min="0" max="100" required>
                            <span class="input-group-text">%</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- GROW LIGHT -->
            <div class="mb-4">
                <div class="text-warning fw-bold border-bottom pb-2 mb-3"><i class="fa-solid fa-lightbulb me-2"></i>LED Grow Light (Intensitas Lux)</div>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label text-secondary small fw-semibold">Intensitas Lampu ON</label>
                        <div class="input-group">
                            <input type="number" name="batas_lux_on" class="form-control" value="{{ $threshold->batas_lux_on }}" required>
                            <span class="input-group-text">Lux</span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label text-secondary small fw-semibold">Intensitas Lampu OFF</label>
                        <div class="input-group">
                            <input type="number" name="batas_lux_off" class="form-control" value="{{ $threshold->batas_lux_off }}" required>
                            <span class="input-group-text">Lux</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TOMBOL SIMPAN -->
            <div class="d-flex justify-content-end gap-2 border-top pt-3">
                <a href="{{ route('dashboard', ['device_code' => $selectedDevice->device_code]) }}" class="btn btn-outline-secondary px-4 rounded-3">Batal</a>
                <button type="submit" class="btn btn-success px-5 rounded-3 fw-bold shadow-sm">Simpan Parameter</button>
            </div>
        </form>
    </div>
    @else
    <div class="alert alert-warning text-center p-5 rounded-3 shadow-sm">
        <i class="fa-solid fa-triangle-exclamation fa-3x mb-3 text-warning"></i>
        <h4>Belum Ada Perangkat Terdaftar</h4>
        <p>Silakan daftarkan perangkat ESP32 baru pada menu <strong>Kelola Device</strong> terlebih dahulu sebelum melakukan pengaturan threshold.</p>
        <a href="{{ route('devices.index') }}" class="btn btn-success rounded-pill px-4 mt-2">Daftarkan Perangkat Sekarang</a>
    </div>
    @endif
</div>
@endsection