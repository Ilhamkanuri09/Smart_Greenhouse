@extends('layouts.app')

@section('title', 'Log Aktivitas Aktuator - Greenhouse')

@section('content')

    <!-- BILAH FILTER PILIHAN PERANGKAT (DROPDOWN FILTER) -->
    <div class="card card-custom p-3 bg-white shadow-sm mb-4 border-start border-success border-5">
        <div class="row align-items-center">
            <div class="col-md-6 mb-2 mb-md-0">
                <h5 class="fw-bold mb-0 text-dark">
                    <i class="fa-solid fa-microchip text-success me-2"></i>Pilih Perangkat Greenhouse:
                </h5>
                <small class="text-muted">Menampilkan catatan riwayat otomatisasi relay berdasarkan perangkat pilihan.</small>
            </div>
            <div class="col-md-6">
                <form action="{{ route('logs.index') }}" method="GET" id="filter-log-device-form">
                    <select name="device_code" class="form-select form-select-lg fw-bold border-success text-success" onchange="document.getElementById('filter-log-device-form').submit()">
                        @forelse($devices as $dev)
                            <option value="{{ $dev->device_code }}" {{ $selectedDevice && $selectedDevice->device_code == $dev->device_code ? 'selected' : '' }}>
                                🌿 {{ $dev->nama_greenhouse }} ({{ $dev->device_code }}) - {{ $dev->lokasi }}
                            </option>
                        @empty
                            <option value="">Belum Ada Perangkat Terdaftar</option>
                        @endforelse
                    </select>
                </form>
            </div>
        </div>
    </div>

    @if($selectedDevice)
    <div class="card card-custom p-4 mb-4 bg-white shadow-sm">
        <div class="d-flex align-items-center mb-3 justify-content-between flex-wrap gap-2">
            <div class="d-flex align-items-center">
                <div class="bg-dark text-white p-3 rounded-3 me-3">
                    <i class="fa-solid fa-clipboard-list fa-2x"></i>
                </div>
                <div>
                    <h4 class="mb-0 fw-bold text-dark">Riwayat Aktivitas Otomatisasi ({{ $selectedDevice->device_code }})</h4>
                    <p class="text-muted mb-0">Daftar rekaman riwayat sistem cerdas untuk <strong>{{ $selectedDevice->nama_greenhouse }}</strong>.</p>
                </div>
            </div>
            <span class="badge bg-success px-3 py-2 fs-6">
                <i class="fa-solid fa-database me-1"></i> Total Log: {{ $logs->total() }}
            </span>
        </div>

        <div class="table-responsive">
            <table class="table table-hover table-striped align-middle mb-3">
                <thead class="table-dark">
                    <tr>
                        <th style="width: 20%;">Waktu Kejadian</th>
                        <th style="width: 20%;">Nama Perangkat</th>
                        <th style="width: 15%;">Aksi Sistem</th>
                        <th style="width: 45%;">Keterangan / Pemicu Kausalitas</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($logs as $log)
                    <tr>
                        <td class="fw-semibold text-secondary">{{ $log->created_at->format('H:i:s / d-M-Y') }}</td>
                        <td>
                            @if(str_contains(strtolower($log->nama_perangkat), 'kipas'))
                                <i class="fa-solid fa-wind text-danger me-1"></i>
                            @elseif(str_contains(strtolower($log->nama_perangkat), 'pompa'))
                                <i class="fa-solid fa-droplet text-primary me-1"></i>
                            @else
                                <i class="fa-solid fa-lightbulb text-warning me-1"></i>
                            @endif
                            {{ $log->nama_perangkat }}
                        </td>
                        <td>
                            <span class="badge bg-{{ $log->status_aksi == 'MENYALA' || $log->status_aksi == 'ON' ? 'success' : 'danger' }} px-3 py-2 rounded-pill">
                                <i class="fa-solid fa-{{ $log->status_aksi == 'MENYALA' || $log->status_aksi == 'ON' ? 'power-off' : 'ban' }} me-1"></i> {{ $log->status_aksi }}
                            </span>
                        </td>
                        <td><span class="text-dark">{{ $log->keterangan_pemicu }}</span></td>
                    </tr>
                    @empty
                    <tr><td colspan="4" class="text-center py-4 text-muted">Belum ada riwayat aktivitas alat yang terekam untuk perangkat ini.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <!-- PAGINASI PINTAR (MENJAGA FILTER DEVICE CODE) -->
        @if($logs->hasPages())
        <div class="d-flex justify-content-end pt-2">
            {{ $logs->appends(['device_code' => $selectedDevice->device_code])->links('pagination::bootstrap-5') }}
        </div>
        @endif
    </div>
    @else
    <div class="alert alert-warning text-center p-5 rounded-3 shadow-sm">
        <i class="fa-solid fa-triangle-exclamation fa-3x mb-3 text-warning"></i>
        <h4>Belum Ada Perangkat Terdaftar</h4>
        <p>Silakan daftarkan perangkat ESP32 baru pada menu <strong>Kelola Device</strong> terlebih dahulu.</p>
    </div>
    @endif

@endsection

@section('scripts')
@if($selectedDevice)
<script>
    const activeDeviceCode = "{{ $selectedDevice->device_code }}";

    const checkLogChannelReady = setInterval(() => {
        if (window.channel) {
            clearInterval(checkLogChannelReady);
            window.channel.bind('SensorEvent', function(data) {
                const incomingDeviceCode = data.deviceCode || (data.sensorData ? data.sensorData.device_code : null);

                // Tarik parsial HTML tabel riwayat log terbaru via AJAX beraliran realtime
                if (incomingDeviceCode === activeDeviceCode) {
                    fetch("{{ route('logs.index') }}?device_code=" + activeDeviceCode, {
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    })
                    .then(response => response.text())
                    .then(html => {
                        const parser = new DOMParser();
                        const doc = parser.parseFromString(html, 'text/html');
                        const newTbody = doc.querySelector('tbody');
                        if (newTbody) {
                            document.querySelector('tbody').innerHTML = newTbody.innerHTML;
                        }
                    })
                    .catch(err => console.error("Gagal sinkronisasi log realtime:", err));
                }
            });
        }
    }, 200);
</script>
@endif
@endsection