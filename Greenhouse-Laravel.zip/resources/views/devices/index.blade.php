@extends('layouts.app')

@section('title', 'Manajemen Perangkat Greenhouse')

@section('content')

<div class="row g-4 mb-5">
    
    <div class="col-md-5">
        <div class="card card-custom bg-white shadow-sm p-4 border-start border-success border-5">
            <h5 class="fw-bold text-dark mb-3">
                <i class="fa-solid fa-plus-circle text-success me-2"></i>Tambah Perangkat Baru
            </h5>
            <p class="text-muted small">Daftarkan node ESP32 baru agar datanya dapat diterima oleh sistem web dashboard.</p>

            @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fa-solid fa-check-circle me-1"></i> {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            @endif

            <form action="{{ route('devices.store') }}" method="POST">
                @csrf
                
                <div class="mb-3">
                    <label for="device_code" class="form-label fw-semibold">
                        Kode Unik Perangkat (Device Code) <span class="text-danger">*</span>
                    </label>
                    <input type="text" 
                           class="form-control @error('device_code') is-invalid @enderror" 
                           id="device_code" 
                           name="device_code" 
                           value="{{ old('device_code') }}" 
                           placeholder="Contoh: GH-01, GH-02" 
                           required>
                    <small class="text-muted">Kode ini wajib diisikan sama persis pada program ESP32.</small>
                    @error('device_code')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="nama_greenhouse" class="form-label fw-semibold">
                        Nama Greenhouse / Sektor <span class="text-danger">*</span>
                    </label>
                    <input type="text" 
                           class="form-control @error('nama_greenhouse') is-invalid @enderror" 
                           id="nama_greenhouse" 
                           name="nama_greenhouse" 
                           value="{{ old('nama_greenhouse') }}" 
                           placeholder="Contoh: Greenhouse Blok A (Pembibitan)" 
                           required>
                    @error('nama_greenhouse')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="lokasi" class="form-label fw-semibold">Lokasi / Keterangan</label>
                    <input type="text" 
                           class="form-control @error('lokasi') is-invalid @enderror" 
                           id="lokasi" 
                           name="lokasi" 
                           value="{{ old('lokasi') }}" 
                           placeholder="Contoh: Kampung Sukawera, Zone 1">
                    @error('lokasi')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <button type="submit" class="btn btn-success rounded-pill w-100 fw-bold">
                    <i class="fa-solid fa-save me-1"></i> Simpan Perangkat
                </button>
            </form>
        </div>
    </div>

    <div class="col-md-7">
        <div class="card card-custom bg-white shadow-sm p-4">
            <h5 class="fw-bold text-dark mb-3">
                <i class="fa-solid fa-microchip text-success me-2"></i>Daftar Perangkat Terdaftar
            </h5>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-success">
                        <tr>
                            <th>No</th>
                            <th>Kode</th>
                            <th>Nama Greenhouse</th>
                            <th>Lokasi</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($devices as $index => $device)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>
                                <span class="badge bg-dark text-white font-monospace">{{ $device->device_code }}</span>
                            </td>
                            <td class="fw-semibold">{{ $device->nama_greenhouse }}</td>
                            <td class="text-muted small">{{ $device->lokasi ?? '-' }}</td>
                            <td class="text-center">
                                <form action="{{ route('devices.destroy', $device->id) }}" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus perangkat ini beserta seluruh data sensornya?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill">
                                        <i class="fa-solid fa-trash-can"></i> Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">
                                <i class="fa-solid fa-folder-open fa-2x mb-2 d-block opacity-50"></i>
                                Belum ada perangkat ESP32 yang terdaftar. Silakan tambahkan lewat form di sebelah kiri.
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

@endsection