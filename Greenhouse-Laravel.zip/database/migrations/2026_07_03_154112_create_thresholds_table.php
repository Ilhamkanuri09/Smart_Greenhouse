<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('thresholds', function (Blueprint $table) {
            $table->id();
            $table->float('batas_suhu_on')->default(33.0);
            $table->float('batas_suhu_off')->default(31.0);
            $table->integer('batas_tanah_on')->default(55);
            $table->integer('batas_tanah_off')->default(65);
            $table->float('batas_lux_on')->default(5000);
            $table->float('batas_lux_off')->default(7000);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('thresholds');
    }
};
