<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sensor_data', function (Blueprint $table) {
            $table->id();
            $table->foreignId('device_id')->constrained('devices')->onDelete('cascade');
            $table->float('suhu');
            $table->float('kelembaban_udara');
            $table->integer('kelembaban_tanah_1');
            $table->integer('kelembaban_tanah_2');
            $table->float('intensitas_cahaya');
            $table->float('tegangan_baterai')->nullable();
            $table->integer('persentase_baterai')->nullable();
            $table->timestamps(); // Menghasilkan created_at (waktu data masuk)
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sensor_data');
    }
};