<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('actuator_logs', function (Blueprint $table) {
            $table->foreignId('device_id')
                ->nullable()
                ->after('id')
                ->constrained('devices')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('actuator_logs', function (Blueprint $table) {
            //
        });
    }
};
