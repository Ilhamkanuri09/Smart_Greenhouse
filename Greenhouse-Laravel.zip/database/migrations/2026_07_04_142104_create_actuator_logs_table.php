<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('actuator_logs', function (Blueprint $table) {
            $table->id();
            $table->string('nama_perangkat'); // Kipas, Pompa Air, atau Grow Light
            $table->string('status_aksi');    // MENYALA atau MATI
            $table->text('keterangan_pemicu'); // Alasan (misal: "Suhu mencapai 34.2°C, melewati batas threshold 33.0°C")
            $table->timestamps();             // created_at otomatis mencatat waktu log
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('actuator_logs');
    }
};