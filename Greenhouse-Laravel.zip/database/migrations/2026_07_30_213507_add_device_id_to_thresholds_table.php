<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('thresholds', function (Blueprint $table) {
            // Menambahkan kolom device_id setelah kolom id
            $table->foreignId('device_id')
                  ->nullable()
                  ->after('id')
                  ->constrained('devices')
                  ->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::table('thresholds', function (Blueprint $table) {
            $table->dropForeign(['device_id']);
            $table->dropColumn('device_id');
        });
    }
};