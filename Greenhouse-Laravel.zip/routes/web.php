<?php

use App\Http\Controllers\DeviceController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ThresholdController;
use App\Http\Controllers\LogController;
use Illuminate\Support\Facades\Route;

// Menu 1: Dashboard Monitoring Realtime
Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

// Route Manajemen Perangkat
Route::get('/devices', [DeviceController::class, 'index'])->name('devices.index');
Route::post('/devices', [DeviceController::class, 'store'])->name('devices.store');
Route::delete('/devices/{id}', [DeviceController::class, 'destroy'])->name('devices.destroy');

// Menu 2: Atur Batas Threshold Otomatisasi (Dua Arah)
Route::get('/threshold', [ThresholdController::class, 'index'])->name('threshold.index');
Route::post('/threshold/update', [ThresholdController::class, 'update'])->name('threshold.update');

// Menu 3: Riwayat Log Aktivitas Perangkat
Route::get('/logs', [LogController::class, 'index'])->name('logs.index');