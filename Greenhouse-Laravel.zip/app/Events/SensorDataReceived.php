<?php

namespace App\Events;

use App\Models\SensorData;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow; // Memotong sistem antrean queue
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class SensorDataReceived implements ShouldBroadcastNow
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $sensorData;
    public $deviceCode;

    public function __construct(SensorData $sensorData, $deviceCode = null)
    {
        $this->sensorData = $sensorData;
        $this->deviceCode = $deviceCode;
    }

    public function broadcastOn(): array
    {
        return [
            new Channel('greenhouse-channel')
        ];
    }

    public function broadcastAs(): string
    {
        return 'SensorEvent';
    }
}