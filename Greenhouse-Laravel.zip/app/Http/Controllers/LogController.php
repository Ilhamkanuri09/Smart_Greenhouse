<?php

namespace App\Http\Controllers;

use App\Models\Device;
use App\Models\ActuatorLog;
use Illuminate\Http\Request;

class LogController extends Controller
{
    public function index(Request $request)
    {
        // 1. Ambil seluruh daftar perangkat untuk dropdown
        $devices = Device::all();

        // 2. Tentukan perangkat mana yang sedang dipilih
        $selectedDeviceCode = $request->get('device_code');
        
        if ($selectedDeviceCode) {
            $selectedDevice = Device::where('device_code', $selectedDeviceCode)->first();
        } else {
            $selectedDevice = $devices->first();
        }

        // Jika belum ada perangkat terdaftar di database
        if (!$selectedDevice) {
            return view('logs', [
                'devices' => collect([]),
                'selectedDevice' => null,
                'logs' => collect([])
            ]);
        }

        // 3. Ambil log riwayat khusus perangkat yang dipilih
        // Catatan: Pastikan kolom device_id sudah dibuat di tabel actuator_logs via migration
        $logs = ActuatorLog::where('device_id', $selectedDevice->id)
                    ->latest()
                    ->paginate(25);

        return view('logs', compact('devices', 'selectedDevice', 'logs'));
    }
}