<?php

namespace App\Http\Controllers;

use App\Models\Device;
use Illuminate\Http\Request;

class DeviceController extends Controller
{
    /**
     * Menampilkan daftar perangkat & form input
     */
    public function index()
    {
        $devices = Device::latest()->get();
        return view('devices.index', compact('devices'));
    }

    /**
     * Menyimpan data perangkat baru ke database
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'device_code'     => 'required|string|max:50|unique:devices,device_code',
            'nama_greenhouse' => 'required|string|max:100',
            'lokasi'          => 'nullable|string|max:150',
        ], [
            'device_code.unique' => 'Kode Perangkat ini sudah terdaftar! Gunakan kode lain.',
            'device_code.required' => 'Kode Perangkat wajib diisi.',
            'nama_greenhouse.required' => 'Nama Greenhouse wajib diisi.',
        ]);

        Device::create($validated);

        return redirect()->route('devices.index')
            ->with('success', 'Perangkat Greenhouse baru berhasil ditambahkan!');
    }

    /**
     * Menghapus perangkat dari database
     */
    public function destroy($id)
    {
        $device = Device::findOrFail($id);
        $device->delete();

        return redirect()->route('devices.index')
            ->with('success', 'Perangkat berhasil dihapus!');
    }
}