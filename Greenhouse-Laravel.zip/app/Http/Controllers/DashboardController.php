<?php

namespace App\Http\Controllers;

use App\Models\Device;
use App\Models\SensorData;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        // 1. Ambil semua daftar perangkat untuk isi Dropdown Select
        $devices = Device::all();

        // 2. Tentukan perangkat mana yang sedang dipilih (Default ke perangkat pertama jika tidak ada pilihan)
        $selectedDeviceCode = $request->get('device_code');
        
        if ($selectedDeviceCode) {
            $selectedDevice = Device::where('device_code', $selectedDeviceCode)->first();
        } else {
            $selectedDevice = $devices->first();
        }

        // Jika belum ada perangkat terdaftar di DB
        if (!$selectedDevice) {
            return view('dashboard', [
                'devices' => collect([]),
                'selectedDevice' => null,
                'latestData' => null,
                'historyData' => collect([])
            ]);
        }

        // 3. Filter data sensor khusus untuk perangkat yang sedang dipilih
        $latestData = SensorData::where('device_id', $selectedDevice->id)->latest()->first();
        $historyData = SensorData::where('device_id', $selectedDevice->id)->latest()->take(10)->get();

        return view('dashboard', compact('devices', 'selectedDevice', 'latestData', 'historyData'));
    }
}