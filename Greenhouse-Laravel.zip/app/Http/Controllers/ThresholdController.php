<?php

namespace App\Http\Controllers;

use App\Models\Device;
use App\Models\Threshold;
use Illuminate\Http\Request;

class ThresholdController extends Controller
{
    /**
     * Menampilkan halaman Form Set Threshold di Web Browser
     */
    public function index(Request $request)
    {
        // 1. Ambil seluruh daftar perangkat untuk dropdown di halaman Web
        $devices = Device::all();

        // 2. Tentukan perangkat mana yang sedang dipilih di Web
        $selectedDeviceCode = $request->get('device_code');
        
        if ($selectedDeviceCode) {
            $selectedDevice = Device::where('device_code', $selectedDeviceCode)->first();
        } else {
            $selectedDevice = $devices->first();
        }

        // Jika belum ada perangkat terdaftar di database
        if (!$selectedDevice) {
            return view('threshold', [
                'devices' => collect([]),
                'selectedDevice' => null,
                'threshold' => (object) [
                    'batas_suhu_on'   => 33.0, 'batas_suhu_off'  => 31.0,
                    'batas_tanah_on'  => 55,   'batas_tanah_off' => 65,
                    'batas_lux_on'    => 5000, 'batas_lux_off'   => 7000
                ]
            ]);
        }

        // 3. Ambil threshold terbaru khusus untuk perangkat yang dipilih
        $threshold = Threshold::where('device_id', $selectedDevice->id)->latest()->first();

        // Jika perangkat tersebut belum memiliki threshold di DB, gunakan nilai default
        if (!$threshold) {
            $threshold = (object) [
                'device_id'       => $selectedDevice->id,
                'batas_suhu_on'   => 33.0, 'batas_suhu_off'  => 31.0,
                'batas_tanah_on'  => 55,   'batas_tanah_off' => 65,
                'batas_lux_on'    => 5000, 'batas_lux_off'   => 7000
            ];
        }

        return view('threshold', compact('devices', 'selectedDevice', 'threshold'));
    }

    /**
     * Memproses simpan data threshold baru dari Form Web Browser
     */
    public function update(Request $request)
    {
        $validated = $request->validate([
            'device_id'       => 'required|exists:devices,id',
            'batas_suhu_on'   => 'required|numeric',
            'batas_suhu_off'  => 'required|numeric',
            'batas_tanah_on'  => 'required|integer|min:0|max:100',
            'batas_tanah_off' => 'required|integer|min:0|max:100',
            'batas_lux_on'    => 'required|numeric',
            'batas_lux_off'   => 'required|numeric',
        ]);

        // Simpan baris threshold baru ke database
        Threshold::create($validated);

        // Ambil data device untuk redirect kembali ke device_code yang sama
        $device = Device::find($request->device_id);

        return redirect()->route('threshold.index', ['device_code' => $device->device_code])
            ->with('success', 'Ambang batas otomatisasi untuk ' . $device->nama_greenhouse . ' (' . $device->device_code . ') berhasil diperbarui!');
    }

    /**
     * API Endpoint khusus yang dipanggil oleh ESP32 (HTTP GET /api/settings)
     */
    public function getSettingsApi(Request $request)
    {
        // Ambil device_code dari query parameter URL (?device_code=GH-01)
        $deviceCode = $request->query('device_code');

        if ($deviceCode) {
            $device = Device::where('device_code', $deviceCode)->first();
            if ($device) {
                $th = Threshold::where('device_id', $device->id)->latest()->first();
            }
        }

        // Fallback jika device_id atau threshold belum dibuat
        if (!isset($th) || !$th) {
            $th = Threshold::latest()->first();
        }

        // Return JSON dengan casting tipe data yang presisi untuk ESP32
        return response()->json([
            'batas_suhu_on'   => (float) ($th->batas_suhu_on ?? 33.0),
            'batas_suhu_off'  => (float) ($th->batas_suhu_off ?? 31.0),
            'batas_tanah_on'  => (int) ($th->batas_tanah_on ?? 55),
            'batas_tanah_off' => (int) ($th->batas_tanah_off ?? 65),
            'batas_lux_on'    => (float) ($th->batas_lux_on ?? 5000),
            'batas_lux_off'   => (float) ($th->batas_lux_off ?? 7000),
        ], 200);
    }
}