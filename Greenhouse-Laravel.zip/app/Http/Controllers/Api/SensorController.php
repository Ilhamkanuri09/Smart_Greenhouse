<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Device;
use App\Models\SensorData;
use App\Models\Threshold;
use App\Models\ActuatorLog;
use App\Events\SensorDataReceived;
use Illuminate\Http\Request;

class SensorController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'device_code'        => 'required|string|exists:devices,device_code',
            'suhu'               => 'required|numeric',
            'kelembaban_udara'   => 'required|numeric',
            'kelembaban_tanah_1' => 'required|integer',
            'kelembaban_tanah_2' => 'required|integer',
            'intensitas_cahaya'  => 'required|numeric',
            'tegangan_baterai'   => 'nullable|numeric',
            'persentase_baterai' => 'nullable|integer',
            'is_charging'        => 'nullable|boolean',
        ]);

        $device = Device::where('device_code', $request->device_code)->first();

        // 1. Simpan data sensor ke DB
        $sensorData = SensorData::create([
            'device_id'          => $device->id,
            'suhu'               => $request->suhu,
            'kelembaban_udara'   => $request->kelembaban_udara,
            'kelembaban_tanah_1' => $request->kelembaban_tanah_1,
            'kelembaban_tanah_2' => $request->kelembaban_tanah_2,
            'intensitas_cahaya'  => $request->intensitas_cahaya,
            'tegangan_baterai'   => $request->tegangan_baterai,
            'persentase_baterai' => $request->persentase_baterai,
            'is_charging'        => $request->is_charging ?? ($request->tegangan_baterai >= 13.0),
        ]);

        // 2. Ambil threshold aktif
        $th = Threshold::where('device_id', $device->id)->latest()->first();
        if(!$th) {
            $th = (object)[
                'batas_suhu_on' => 33.0, 'batas_suhu_off' => 31.0,
                'batas_tanah_on' => 55, 'batas_tanah_off' => 65,
                'batas_lux_on' => 5000, 'batas_lux_off' => 7000
            ];
        }

        // 3. Trigger Broadcast (Gunakan try-catch agar jika Pusher lambat/gagal, API tetap sukses)
        try {
            broadcast(new SensorDataReceived($sensorData, $device->device_code))->toOthers();
        } catch (\Exception $e) {
            // Abaikan error jaringan Pusher agar respons POST ke ESP32 tetap kencang
        }

        // 4. Sistem Logging Ringkas (DISESUAIKAN DENGAN DEVICE_ID)
        $tanahMin = min($sensorData->kelembaban_tanah_1, $sensorData->kelembaban_tanah_2);
        $tanahMax = max($sensorData->kelembaban_tanah_1, $sensorData->kelembaban_tanah_2);

        // Kipas Exhaust
        if ($sensorData->suhu >= $th->batas_suhu_on) {
            $exists = ActuatorLog::where('device_id', $device->id)
                ->where('nama_perangkat', 'Kipas Exhaust')
                ->where('status_aksi', 'MENYALA')
                ->where('created_at', '>=', now()->subMinute())
                ->exists();

            if (!$exists) { 
                ActuatorLog::create([
                    'device_id'          => $device->id, // <-- TAMBAHKAN DI SINI
                    'nama_perangkat'    => 'Kipas Exhaust', 
                    'status_aksi'       => 'MENYALA', 
                    'keterangan_pemicu' => "Suhu kritis tinggi: {$sensorData->suhu}°C."
                ]); 
            }
        } elseif ($sensorData->suhu <= $th->batas_suhu_off) {
            $exists = ActuatorLog::where('device_id', $device->id)
                ->where('nama_perangkat', 'Kipas Exhaust')
                ->where('status_aksi', 'MATI')
                ->where('created_at', '>=', now()->subMinute())
                ->exists();

            if (!$exists) { 
                ActuatorLog::create([
                    'device_id'          => $device->id, // <-- TAMBAHKAN DI SINI
                    'nama_perangkat'    => 'Kipas Exhaust', 
                    'status_aksi'       => 'MATI', 
                    'keterangan_pemicu' => "Suhu stabil: {$sensorData->suhu}°C."
                ]); 
            }
        }

        // Pompa Air
        if ($tanahMin < $th->batas_tanah_on) {
            $exists = ActuatorLog::where('device_id', $device->id)
                ->where('nama_perangkat', 'Pompa Air')
                ->where('status_aksi', 'MENYALA')
                ->where('created_at', '>=', now()->subMinute())
                ->exists();

            if (!$exists) { 
                ActuatorLog::create([
                    'device_id'          => $device->id, // <-- TAMBAHKAN DI SINI
                    'nama_perangkat'    => 'Pompa Air', 
                    'status_aksi'       => 'MENYALA', 
                    'keterangan_pemicu' => "Tanah kering (Sensor 1: {$sensorData->kelembaban_tanah_1}%, Sensor 2: {$sensorData->kelembaban_tanah_2}%)."
                ]); 
            }
        } elseif ($tanahMax > $th->batas_tanah_off) {
            $exists = ActuatorLog::where('device_id', $device->id)
                ->where('nama_perangkat', 'Pompa Air')
                ->where('status_aksi', 'MATI')
                ->where('created_at', '>=', now()->subMinute())
                ->exists();

            if (!$exists) { 
                ActuatorLog::create([
                    'device_id'          => $device->id, // <-- TAMBAHKAN DI SINI
                    'nama_perangkat'    => 'Pompa Air', 
                    'status_aksi'       => 'MATI', 
                    'keterangan_pemicu' => "Kelembaban tanah terlewati."
                ]); 
            }
        }

        // LED Grow Light
        if ($sensorData->intensitas_cahaya < $th->batas_lux_on) {
            $exists = ActuatorLog::where('device_id', $device->id)
                ->where('nama_perangkat', 'LED Grow Light')
                ->where('status_aksi', 'MENYALA')
                ->where('created_at', '>=', now()->subMinute())
                ->exists();

            if (!$exists) { 
                ActuatorLog::create([
                    'device_id'          => $device->id, // <-- TAMBAHKAN DI SINI
                    'nama_perangkat'    => 'LED Grow Light', 
                    'status_aksi'       => 'MENYALA', 
                    'keterangan_pemicu' => "Redup: {$sensorData->intensitas_cahaya} Lux."
                ]); 
            }
        } elseif ($sensorData->intensitas_cahaya > $th->batas_lux_off) {
            $exists = ActuatorLog::where('device_id', $device->id)
                ->where('nama_perangkat', 'LED Grow Light')
                ->where('status_aksi', 'MATI')
                ->where('created_at', '>=', now()->subMinute())
                ->exists();

            if (!$exists) { 
                ActuatorLog::create([
                    'device_id'          => $device->id, // <-- TAMBAHKAN DI SINI
                    'nama_perangkat'    => 'LED Grow Light', 
                    'status_aksi'       => 'MATI', 
                    'keterangan_pemicu' => "Terang: {$sensorData->intensitas_cahaya} Lux."
                ]); 
            }
        }

        // 5. Kembalikan respons secepat mungkin ke ESP32
        return response()->json([
            'status' => 'success',
            'threshold' => [
                'batas_suhu_on'   => (float) $th->batas_suhu_on,
                'batas_suhu_off'  => (float) $th->batas_suhu_off,
                'batas_tanah_on'  => (int) $th->batas_tanah_on,
                'batas_tanah_off' => (int) $th->batas_tanah_off,
                'batas_lux_on'    => (float) $th->batas_lux_on,
                'batas_lux_off'   => (float) $th->batas_lux_off,
            ]
        ], 201);
    }
}