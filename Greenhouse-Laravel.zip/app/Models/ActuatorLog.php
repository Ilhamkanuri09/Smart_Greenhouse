<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ActuatorLog extends Model
{
    use HasFactory;

    protected $table = 'actuator_logs';

    protected $fillable = [
        'device_id',
        'nama_perangkat',
        'status_aksi',
        'keterangan_pemicu'
    ];
    public function device()
    {
        return $this->belongsTo(Device::class, 'device_id', 'id');
    }
}