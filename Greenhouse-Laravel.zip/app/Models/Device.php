<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Device extends Model
{
    use HasFactory;

    protected $table = 'devices';

    protected $fillable = [
        'device_code',     // Kode Unik (misal: "GH-01", "GH-02")
        'nama_greenhouse', // Nama Perangkat (misal: "Greenhouse Blok A")
        'lokasi',          // Lokasi (misal: "Kampung Sukawera")
    ];
    public function sensorData()
    {
        return $this->hasMany(SensorData::class, 'device_id', 'id');
    }
    public function thresholds()
    {
        return $this->hasMany(Threshold::class, 'device_id', 'id');
    }
}