<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Threshold extends Model
{
    use HasFactory;

    protected $table = 'thresholds';

    protected $fillable = [
        'device_id', 
        'batas_suhu_on',
        'batas_suhu_off',
        'batas_tanah_on',
        'batas_tanah_off',
        'batas_lux_on',
        'batas_lux_off',
    ];
    public function device()
    {
        return $this->belongsTo(Device::class, 'device_id', 'id');
    }
}
