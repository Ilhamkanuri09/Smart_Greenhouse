<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SensorData extends Model
{
    use HasFactory;

    protected $table = 'sensor_data';

    protected $fillable = [
        'device_id',
        'suhu',
        'kelembaban_udara',
        'kelembaban_tanah_1',
        'kelembaban_tanah_2',
        'intensitas_cahaya',
        'tegangan_baterai',
        'persentase_baterai',
        'is_charging',
    ];
    public function device()
    {
        return $this->belongsTo(Device::class, 'device_id', 'id');
    }
}