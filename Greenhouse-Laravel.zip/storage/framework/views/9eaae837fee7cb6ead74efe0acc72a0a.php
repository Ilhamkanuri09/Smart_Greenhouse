<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Greenhouse Cerdas'); ?></title>

    <!-- Bootstrap 5 & FontAwesome CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body { 
            background-color: #f4f6f9; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
        }
        .card-custom { 
            border: none; 
            border-radius: 15px; 
            box-shadow: 0 4px 6px rgba(0,0,0,0.05); 
        }
        /* Penyesuaian kustom untuk perangkat mobile */
        @media (max-width: 991.88px) {
            .nav-buttons-container {
                margin-top: 15px;
                flex-direction: column;
                align-items: stretch !important;
            }
            .nav-buttons-container .btn {
                width: 100%;
                text-align: left;
                margin-bottom: 8px;
            }
            .nav-buttons-container #status-koneksi {
                margin-left: 0 !important;
                margin-top: 5px;
                text-align: center;
                display: block;
            }
        }
    </style>
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>

<!-- NAVBAR RESPONSIVE -->
<nav class="navbar navbar-expand-lg navbar-dark bg-success mb-4 shadow-sm">
    <div class="container">
        <!-- Brand / Logo Header -->
        <a class="navbar-brand fw-bold d-flex align-items-center" href="<?php echo e(route('dashboard')); ?>">
            <i class="fa-solid fa-leaf me-2"></i>
            <span>Sukawera Greenhouse</span>
        </a>

        <!-- Tombol Toggler (Muncul otomatis di Layar HP/Tablet) -->
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Container Menu Navigasi yang bisa diciutkan di HP -->
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <div class="ms-auto d-flex align-items-center nav-buttons-container">
                <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-sm rounded-pill px-3 me-lg-2 <?php echo e(Route::is('dashboard') ? 'btn-light text-success active fw-bold' : 'btn-outline-light'); ?>">
                    <i class="fa-solid fa-chart-line me-1"></i> Dashboard Monitor
                </a>
                <a href="<?php echo e(route('devices.index')); ?>" class="btn btn-sm rounded-pill px-3 me-lg-2 <?php echo e(Route::is('devices.index') ? 'btn-light text-success active fw-bold' : 'btn-outline-light'); ?>">
                    <i class="fa-solid fa-microchip me-1"></i> Kelola Device
                </a>
                <a href="<?php echo e(route('threshold.index')); ?>" class="btn btn-sm rounded-pill px-3 me-lg-2 <?php echo e(Route::is('threshold.index') ? 'btn-light text-success active fw-bold' : 'btn-outline-light'); ?>">
                    <i class="fa-solid fa-sliders me-1"></i> Pengaturan
                </a>
                <a href="<?php echo e(route('logs.index')); ?>" class="btn btn-sm rounded-pill px-3 me-lg-2 <?php echo e(Route::is('logs.index') ? 'btn-light text-success active fw-bold' : 'btn-outline-light'); ?>">
                    <i class="fa-solid fa-history me-1"></i> Riwayat Perangkat
                </a>

                <!-- Indikator Koneksi Pusher -->
                <span class="navbar-text text-white bg-dark px-3 py-1 rounded-pill ms-lg-2 d-none" id="status-koneksi">
                    <i class="fa-solid fa-circle text-warning me-1 animate-pulse"></i> Connecting...
                </span>
            </div>
        </div>
    </div>
</nav>

<!-- MAIN CONTENT CONTAINER RESPONSIVE -->
<main class="container mb-5">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Library Pusher Client Global -->
<script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
<script>
    // Ambil kredensial Pusher aman lewat file config Laravel
    const pusherKey = "<?php echo e(config('broadcasting.connections.pusher.key')); ?>";
    const pusherCluster = "<?php echo e(config('broadcasting.connections.pusher.options.cluster')); ?>";
    
    var pusher = null;
    var channel = null;

    if (pusherKey) {
        pusher = new Pusher(pusherKey, { cluster: pusherCluster, forceTLS: true });
        channel = pusher.subscribe('greenhouse-channel');
        
        window.pusher = pusher;
        window.channel = channel;

        const connectionBadge = document.getElementById('status-koneksi');
        if (connectionBadge) {
            connectionBadge.classList.remove('d-none');
            pusher.connection.bind('connected', function() {
                connectionBadge.innerHTML = '<i class="fa-solid fa-circle text-success me-1"></i> Realtime Aktif';
            });
            pusher.connection.bind('disconnected', function() {
                connectionBadge.innerHTML = '<i class="fa-solid fa-circle text-danger me-1"></i> Terputus';
            });
        }
    }
</script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH /home/sukawera/laravel-app/resources/views/layouts/app.blade.php ENDPATH**/ ?>