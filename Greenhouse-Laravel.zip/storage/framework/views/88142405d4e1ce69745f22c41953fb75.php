

<?php $__env->startSection('title', 'Manajemen Perangkat Greenhouse'); ?>

<?php $__env->startSection('content'); ?>

<div class="row g-4 mb-5">
    
    <div class="col-md-5">
        <div class="card card-custom bg-white shadow-sm p-4 border-start border-success border-5">
            <h5 class="fw-bold text-dark mb-3">
                <i class="fa-solid fa-plus-circle text-success me-2"></i>Tambah Perangkat Baru
            </h5>
            <p class="text-muted small">Daftarkan node ESP32 baru agar datanya dapat diterima oleh sistem web dashboard.</p>

            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fa-solid fa-check-circle me-1"></i> <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('devices.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                
                <div class="mb-3">
                    <label for="device_code" class="form-label fw-semibold">
                        Kode Unik Perangkat (Device Code) <span class="text-danger">*</span>
                    </label>
                    <input type="text" 
                           class="form-control <?php $__errorArgs = ['device_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           id="device_code" 
                           name="device_code" 
                           value="<?php echo e(old('device_code')); ?>" 
                           placeholder="Contoh: GH-01, GH-02" 
                           required>
                    <small class="text-muted">Kode ini wajib diisikan sama persis pada program ESP32.</small>
                    <?php $__errorArgs = ['device_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="nama_greenhouse" class="form-label fw-semibold">
                        Nama Greenhouse / Sektor <span class="text-danger">*</span>
                    </label>
                    <input type="text" 
                           class="form-control <?php $__errorArgs = ['nama_greenhouse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           id="nama_greenhouse" 
                           name="nama_greenhouse" 
                           value="<?php echo e(old('nama_greenhouse')); ?>" 
                           placeholder="Contoh: Greenhouse Blok A (Pembibitan)" 
                           required>
                    <?php $__errorArgs = ['nama_greenhouse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="lokasi" class="form-label fw-semibold">Lokasi / Keterangan</label>
                    <input type="text" 
                           class="form-control <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           id="lokasi" 
                           name="lokasi" 
                           value="<?php echo e(old('lokasi')); ?>" 
                           placeholder="Contoh: Kampung Sukawera, Zone 1">
                    <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="btn btn-success rounded-pill w-100 fw-bold">
                    <i class="fa-solid fa-save me-1"></i> Simpan Perangkat
                </button>
            </form>
        </div>
    </div>

    <div class="col-md-7">
        <div class="card card-custom bg-white shadow-sm p-4">
            <h5 class="fw-bold text-dark mb-3">
                <i class="fa-solid fa-microchip text-success me-2"></i>Daftar Perangkat Terdaftar
            </h5>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-success">
                        <tr>
                            <th>No</th>
                            <th>Kode</th>
                            <th>Nama Greenhouse</th>
                            <th>Lokasi</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <span class="badge bg-dark text-white font-monospace"><?php echo e($device->device_code); ?></span>
                            </td>
                            <td class="fw-semibold"><?php echo e($device->nama_greenhouse); ?></td>
                            <td class="text-muted small"><?php echo e($device->lokasi ?? '-'); ?></td>
                            <td class="text-center">
                                <form action="<?php echo e(route('devices.destroy', $device->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus perangkat ini beserta seluruh data sensornya?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill">
                                        <i class="fa-solid fa-trash-can"></i> Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">
                                <i class="fa-solid fa-folder-open fa-2x mb-2 d-block opacity-50"></i>
                                Belum ada perangkat ESP32 yang terdaftar. Silakan tambahkan lewat form di sebelah kiri.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\greenhouse-laravel\resources\views/devices/index.blade.php ENDPATH**/ ?>