

<?php $__env->startSection('title', 'Dashboard Monitoring Multi-Device'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .card-sensor { 
        border: none; 
        border-radius: 12px; 
        box-shadow: 0 2px 8px rgba(0,0,0,0.06); 
        transition: all 0.2s ease-in-out; 
    }
    .card-sensor:hover { transform: translateY(-3px); }
    .sensor-value { font-size: 1.8rem; font-weight: 700; line-height: 1.2; }
    .sensor-label { font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
    .status-badge { font-size: 0.8rem; font-weight: 700; padding: 4px 12px; border-radius: 50px; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-3">

    <div class="card card-custom p-3 bg-white shadow-sm mb-3 border-start border-success border-5">
        <div class="row align-items-center g-2">
            <div class="col-lg-5 col-md-6">
                <form action="<?php echo e(route('dashboard')); ?>" method="GET" id="filter-device-form">
                    <div class="input-group">
                        <span class="input-group-text bg-success text-white border-success fw-bold">
                            <i class="fa-solid fa-microchip me-2"></i> Perangkat:
                        </span>
                        <select name="device_code" class="form-select fw-bold border-success text-success" onchange="document.getElementById('filter-device-form').submit()">
                            <?php $__empty_1 = true; $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($dev->device_code); ?>" <?php echo e($selectedDevice && $selectedDevice->device_code == $dev->device_code ? 'selected' : ''); ?>>
                                    🌿 <?php echo e($dev->nama_greenhouse); ?> (<?php echo e($dev->device_code); ?>) - <?php echo e($dev->lokasi); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option value="">Belum Ada Perangkat Terdaftar</option>
                            <?php endif; ?>
                        </select>
                    </div>
                </form>
            </div>

            <?php if($selectedDevice): ?>
            <div class="col-lg-7 col-md-6 text-md-end">
                <div class="d-inline-flex gap-2 flex-wrap align-items-center justify-content-md-end">
                    <span class="small fw-bold text-muted me-1"><i class="fa-solid fa-toggle-on me-1"></i> Relay:</span>
                    <div class="bg-light px-2 py-1 rounded-3 border d-flex align-items-center">
                        <i class="fa-solid fa-wind text-danger me-1 small"></i>
                        <span class="me-2 x-small fw-semibold">Kipas:</span>
                        <span id="status-kipas" class="status-badge bg-secondary text-white">OFF</span>
                    </div>
                    <div class="bg-light px-2 py-1 rounded-3 border d-flex align-items-center">
                        <i class="fa-solid fa-droplet text-primary me-1 small"></i>
                        <span class="me-2 x-small fw-semibold">Pompa:</span>
                        <span id="status-pompa" class="status-badge bg-secondary text-white">OFF</span>
                    </div>
                    <div class="bg-light px-2 py-1 rounded-3 border d-flex align-items-center">
                        <i class="fa-solid fa-lightbulb text-warning me-1 small"></i>
                        <span class="me-2 x-small fw-semibold">Grow Light:</span>
                        <span id="status-lampu" class="status-badge bg-secondary text-white">OFF</span>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if($selectedDevice): ?>

    <div class="row g-3 mb-3">
        <!-- Kartu Baterai Aki (Solar Power) -->
        <div class="col-xl-2 col-md-4 col-6">
            <div class="card card-sensor bg-white border-start border-primary border-4 p-2 ps-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <div class="sensor-label text-muted d-flex align-items-center gap-1">
                            Baterai Aki (Solar)
                            <!-- BADGE INDIKATOR CHARGING PETIR -->
                            <span id="badge-charging" class="badge <?php echo e($latestData && ($latestData->is_charging || $latestData->tegangan_baterai >= 13.0) ? 'bg-warning text-dark' : 'bg-secondary text-white'); ?> x-small px-2 py-1 ms-1">
                                <i class="fa-solid <?php echo e($latestData && ($latestData->is_charging || $latestData->tegangan_baterai >= 13.0) ? 'fa-bolt fa-bounce' : 'fa-battery-half'); ?> me-1"></i>
                                <span id="txt-charging"><?php echo e($latestData && ($latestData->is_charging || $latestData->tegangan_baterai >= 13.0) ? 'CHARGING' : 'STANDBY'); ?></span>
                            </span>
                        </div>
                        <div class="d-flex align-items-baseline gap-1">
                            <div class="sensor-value text-primary" id="val-battery-pct">
                                <?php echo e($latestData ? $latestData->persentase_baterai ?? 0 : '0'); ?><span class="fs-6">%</span>
                            </div>
                            <span class="small text-muted fw-bold" id="val-battery-v">
                                (<?php echo e($latestData ? number_format($latestData->tegangan_baterai ?? 0, 2) : '0.00'); ?>V)
                            </span>
                        </div>
                    </div>
                    <!-- IKON PETIR / BATERAI BERUBAH WARNA -->
                    <i id="icon-battery" class="fa-solid <?php echo e($latestData && ($latestData->is_charging || $latestData->tegangan_baterai >= 13.0) ? 'fa-bolt-lightning text-warning' : 'fa-car-battery text-primary'); ?> fa-2x opacity-50 me-2"></i>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6">
            <div class="card card-sensor bg-white border-start border-danger border-4 p-2 ps-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <div class="sensor-label text-muted">Suhu Udara</div>
                        <div class="sensor-value text-danger" id="val-suhu">
                            <?php echo e($latestData ? number_format($latestData->suhu, 1) : '0.0'); ?> <span class="fs-6">°C</span>
                        </div>
                    </div>
                    <i class="fa-solid fa-temperature-high fa-2x text-danger opacity-25 me-2"></i>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6">
            <div class="card card-sensor bg-white border-start border-info border-4 p-2 ps-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <div class="sensor-label text-muted">Kelembaban Udara</div>
                        <div class="sensor-value text-info" id="val-humidity">
                            <?php echo e($latestData ? number_format($latestData->kelembaban_udara, 1) : '0.0'); ?> <span class="fs-6">%</span>
                        </div>
                    </div>
                    <i class="fa-solid fa-cloud-sun-rain fa-2x text-info opacity-25 me-2"></i>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6">
            <div class="card card-sensor bg-white border-start border-warning border-4 p-2 ps-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <div class="sensor-label text-muted">Intensitas Cahaya</div>
                        <div class="sensor-value text-warning" id="val-lux">
                            <?php echo e($latestData ? number_format($latestData->intensitas_cahaya, 0) : '0'); ?> <span class="fs-6">Lux</span>
                        </div>
                    </div>
                    <i class="fa-solid fa-sun fa-2x text-warning opacity-25 me-2"></i>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6">
            <div class="card card-sensor bg-white border-start border-success border-4 p-2 ps-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <div class="sensor-label text-muted">Tanah Sensor 1</div>
                        <div class="sensor-value text-success" id="val-soil1">
                            <?php echo e($latestData ? $latestData->kelembaban_tanah_1 : '0'); ?> <span class="fs-6">%</span>
                        </div>
                    </div>
                    <i class="fa-solid fa-seedling fa-2x text-success opacity-25 me-2"></i>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6">
            <div class="card card-sensor bg-white border-start border-success border-4 p-2 ps-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <div class="sensor-label text-muted">Tanah Sensor 2</div>
                        <div class="sensor-value text-success" id="val-soil2">
                            <?php echo e($latestData ? $latestData->kelembaban_tanah_2 : '0'); ?> <span class="fs-6">%</span>
                        </div>
                    </div>
                    <i class="fa-solid fa-seedling fa-2x text-success opacity-25 me-2"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-3">
        <div class="col-12">
            <div class="card card-custom p-3 bg-white shadow-sm">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h6 class="fw-bold text-dark mb-0">
                        <i class="fa-solid fa-chart-line me-2 text-success"></i>Grafik Tren Parameter - <?php echo e($selectedDevice->nama_greenhouse); ?>

                    </h6>
                    <small class="text-muted"><i class="fa-solid fa-sync fa-spin text-success me-1"></i> Realtime Update</small>
                </div>
                <div style="position: relative; height:240px; width:100%">
                    <canvas id="greenhouseChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-dark text-white fw-bold py-2 small">
            <i class="fa-solid fa-clock-rotate-left me-2"></i> 10 Riwayat Terakhir (<?php echo e($selectedDevice->device_code); ?>)
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle mb-0 small" id="sensor-table">
                    <thead class="table-secondary">
                        <tr>
                            <th>Waktu Terbaca</th>
                            <th>Suhu (°C)</th>
                            <th>Kelembaban Udara (%)</th>
                            <th>Tanah Sensor 1 (%)</th>
                            <th>Tanah Sensor 2 (%)</th>
                            <th>Intensitas (Lux)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $historyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($row->created_at->format('H:i:s / d-M-Y')); ?></td>
                            <td class="fw-semibold text-danger"><?php echo e($row->suhu); ?></td>
                            <td class="fw-semibold text-info"><?php echo e($row->kelembaban_udara); ?></td>
                            <td class="fw-semibold text-success"><?php echo e($row->kelembaban_tanah_1); ?>%</td>
                            <td class="fw-semibold text-success"><?php echo e($row->kelembaban_tanah_2); ?>%</td>
                            <td class="fw-semibold text-warning"><?php echo e(number_format($row->intensitas_cahaya, 0)); ?> Lux</td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr id="empty-row"><td colspan="6" class="text-center text-muted py-3">Belum ada data sensor untuk perangkat ini.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php else: ?>
    <div class="alert alert-warning text-center p-5 rounded-3 shadow-sm">
        <i class="fa-solid fa-triangle-exclamation fa-3x mb-3 text-warning"></i>
        <h4>Belum Ada Perangkat Terdaftar</h4>
        <p>Silakan daftarkan perangkat ESP32 baru pada database/menu Kelola Device terlebih dahulu.</p>
    </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php if($selectedDevice): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const activeDeviceCode = "<?php echo e($selectedDevice->device_code); ?>";
    const initialData = <?php echo json_encode($historyData ? $historyData->reverse()->values() : [], 15, 512) ?>;
    
    // Threshold lokal
    const thSuhuOn   = parseFloat("<?php echo e(\App\Models\Threshold::where('device_id', $selectedDevice->id)->latest()->first()->batas_suhu_on ?? 33.0); ?>");
    const thSuhuOff  = parseFloat("<?php echo e(\App\Models\Threshold::where('device_id', $selectedDevice->id)->latest()->first()->batas_suhu_off ?? 31.0); ?>");
    const thTanahOn  = parseInt("<?php echo e(\App\Models\Threshold::where('device_id', $selectedDevice->id)->latest()->first()->batas_tanah_on ?? 55); ?>");
    const thTanahOff = parseInt("<?php echo e(\App\Models\Threshold::where('device_id', $selectedDevice->id)->latest()->first()->batas_tanah_off ?? 65); ?>");
    const thLuxOn    = parseFloat("<?php echo e(\App\Models\Threshold::where('device_id', $selectedDevice->id)->latest()->first()->batas_lux_on ?? 5000); ?>");
    const thLuxOff   = parseFloat("<?php echo e(\App\Models\Threshold::where('device_id', $selectedDevice->id)->latest()->first()->batas_lux_off ?? 7000); ?>");

    let labels = []; let suhuData = []; let humData = []; let soil1Data = [];

    if (initialData && initialData.length > 0) {
        labels = initialData.map(item => {
            const d = new Date(item.created_at);
            return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        });
        suhuData = initialData.map(item => item.suhu || 0);
        humData = initialData.map(item => item.kelembaban_udara || 0);
        soil1Data = initialData.map(item => item.kelembaban_tanah_1 || 0);
    }

    const ctx = document.getElementById('greenhouseChart').getContext('2d');
    const greenhouseChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                { label: 'Suhu (°C)', data: suhuData, borderColor: '#dc3545', backgroundColor: 'transparent', tension: 0.3, borderWidth: 2 },
                { label: 'Kelembaban Udara (%)', data: humData, borderColor: '#0dcaf0', backgroundColor: 'transparent', tension: 0.3, borderWidth: 2 },
                { label: 'Tanah (%)', data: soil1Data, borderColor: '#198754', backgroundColor: 'transparent', tension: 0.3, borderWidth: 2, borderDash: [4,4] }
            ]
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: false, 
            scales: { y: { beginAtZero: false } },
            plugins: { legend: { position: 'top', labels: { boxWidth: 12, font: { size: 11 } } } }
        }
    });

    function hitungStatusAktuator(suhu, tanah1, tanah2, lux) {
        const badgeKipas = document.getElementById('status-kipas');
        if (badgeKipas) {
            if (suhu >= thSuhuOn) { badgeKipas.innerHTML = 'ON'; badgeKipas.className = 'status-badge bg-success text-white'; }
            else if (suhu <= thSuhuOff) { badgeKipas.innerHTML = 'OFF'; badgeKipas.className = 'status-badge bg-danger text-white'; }
        }
        const badgePompa = document.getElementById('status-pompa');
        if (badgePompa) {
            if (tanah1 < thTanahOn || tanah2 < thTanahOn) { badgePompa.innerHTML = 'ON'; badgePompa.className = 'status-badge bg-success text-white'; }
            else if (tanah1 > thTanahOff && tanah2 > thTanahOff) { badgePompa.innerHTML = 'OFF'; badgePompa.className = 'status-badge bg-danger text-white'; }
        }
        const badgeLampu = document.getElementById('status-lampu');
        if (badgeLampu) {
            if (lux < thLuxOn) { badgeLampu.innerHTML = 'ON'; badgeLampu.className = 'status-badge bg-success text-white'; }
            else if (lux > thLuxOff) { badgeLampu.innerHTML = 'OFF'; badgeLampu.className = 'status-badge bg-danger text-white'; }
        }
    }

    if (initialData && initialData.length > 0) {
        const last = initialData[initialData.length - 1];
        hitungStatusAktuator(last.suhu, last.kelembaban_tanah_1, last.kelembaban_tanah_2, last.intensitas_cahaya);
    }

    // LISTENER PUSHER REALTIME
    const checkChannelReady = setInterval(() => {
        if (window.channel) {
            clearInterval(checkChannelReady);

            window.channel.bind('SensorEvent', function(data) {
                const sensor = data.sensorData;
                const incomingDeviceCode = data.deviceCode || (sensor ? sensor.device_code : null);

                if (sensor && (incomingDeviceCode === activeDeviceCode)) {
                    document.getElementById('val-suhu').innerHTML = parseFloat(sensor.suhu).toFixed(1) + ' <span class="fs-6">°C</span>';
                    document.getElementById('val-humidity').innerHTML = parseFloat(sensor.kelembaban_udara).toFixed(1) + ' <span class="fs-6">%</span>';
                    document.getElementById('val-lux').innerHTML = parseFloat(sensor.intensitas_cahaya).toFixed(0) + ' <span class="fs-6">Lux</span>';
                    document.getElementById('val-soil1').innerHTML = sensor.kelembaban_tanah_1 + ' <span class="fs-6">%</span>';
                    document.getElementById('val-soil2').innerHTML = sensor.kelembaban_tanah_2 + ' <span class="fs-6">%</span>';

                    if(document.getElementById('val-battery-pct')) {
                        document.getElementById('val-battery-pct').innerHTML = (sensor.persentase_baterai || 0) + '<span class="fs-6">%</span>';
                    }
                    if(document.getElementById('val-battery-v')) {
                        document.getElementById('val-battery-v').innerHTML = '(' + parseFloat(sensor.tegangan_baterai || 0).toFixed(2) + 'V)';
                    }
                    
                    const tegangan = parseFloat(sensor.tegangan_baterai || 0);
                    const isCharging = (sensor.is_charging === true || sensor.is_charging === 1 || sensor.is_charging === "1" || tegangan >= 13.0);
                    
                    const badgeCharging = document.getElementById('badge-charging');
                    const iconBattery   = document.getElementById('icon-battery');
                    
                    if (badgeCharging) {
                        if (isCharging) {
                            badgeCharging.className = 'badge bg-warning text-dark x-small px-2 py-1 ms-1';
                            badgeCharging.innerHTML = '<i class="fa-solid fa-bolt fa-bounce me-1"></i> CHARGING';
                            if(iconBattery) iconBattery.className = 'fa-solid fa-bolt-lightning text-warning fa-2x opacity-75 me-2';
                        } else {
                            badgeCharging.className = 'badge bg-secondary text-white x-small px-2 py-1 ms-1';
                            badgeCharging.innerHTML = '<i class="fa-solid fa-battery-half me-1"></i> STANDBY';
                            if(iconBattery) iconBattery.className = 'fa-solid fa-car-battery text-primary fa-2x opacity-50 me-2';
                        }
                    }

                    hitungStatusAktuator(sensor.suhu, sensor.kelembaban_tanah_1, sensor.kelembaban_tanah_2, sensor.intensitas_cahaya);

                    const date = new Date(sensor.created_at || new Date());
                    const timeStr = date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                    
                    greenhouseChart.data.labels.push(timeStr);
                    greenhouseChart.data.datasets[0].data.push(sensor.suhu);
                    greenhouseChart.data.datasets[1].data.push(sensor.kelembaban_udara);
                    greenhouseChart.data.datasets[2].data.push(sensor.kelembaban_tanah_1);

                    if (greenhouseChart.data.labels.length > 10) {
                        greenhouseChart.data.labels.shift();
                        greenhouseChart.data.datasets[0].data.shift();
                        greenhouseChart.data.datasets[1].data.shift();
                        greenhouseChart.data.datasets[2].data.shift();
                    }
                    greenhouseChart.update();

                    const formattedTime = timeStr + ' / ' + date.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
                    const tableBody = document.querySelector('#sensor-table tbody');
                    if (tableBody) {
                        const emptyRow = document.getElementById('empty-row'); if (emptyRow) emptyRow.remove();
                        const newRow = document.createElement('tr');
                        newRow.innerHTML = `<td>${formattedTime}</td><td class="fw-semibold text-danger">${parseFloat(sensor.suhu).toFixed(1)}</td><td class="fw-semibold text-info">${parseFloat(sensor.kelembaban_udara).toFixed(1)}</td><td class="fw-semibold text-success">${sensor.kelembaban_tanah_1}%</td><td class="fw-semibold text-success">${sensor.kelembaban_tanah_2}%</td><td class="fw-semibold text-warning">${parseFloat(sensor.intensitas_cahaya).toLocaleString('id-ID')} Lux</td>`;
                        tableBody.insertBefore(newRow, tableBody.firstChild);
                        if (tableBody.children.length > 10) tableBody.removeChild(tableBody.lastChild);
                    }
                }
            });
        }
    }, 200);
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sukawera/laravel-app/resources/views/dashboard.blade.php ENDPATH**/ ?>