

<?php $__env->startSection('title', 'Dashboard Monitoring Multi-Device'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .card-sensor { border: none; border-radius: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); transition: transform 0.2s; }
    .card-sensor:hover { transform: translateY(-5px); }
    .sensor-value { font-size: 2.3rem; font-weight: bold; }
    .status-badge { font-size: 0.9rem; font-weight: 600; padding: 6px 16px; border-radius: 50px; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card card-custom p-3 bg-white shadow-sm mb-4 border-start border-success border-5">
        <div class="row align-items-center">
            <div class="col-md-6 mb-2 mb-md-0">
                <h5 class="fw-bold mb-0 text-dark">
                    <i class="fa-solid fa-microchip text-success me-2"></i>Pilih Perangkat Greenhouse:
                </h5>
                <small class="text-muted">Menampilkan data monitoring dan grafik secara realtime berdasarkan node pilihan.</small>
            </div>
            <div class="col-md-6">
                <form action="<?php echo e(route('dashboard')); ?>" method="GET" id="filter-device-form">
                    <select name="device_code" class="form-select form-select-lg fw-bold border-success text-success" onchange="document.getElementById('filter-device-form').submit()">
                        <?php $__empty_1 = true; $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($dev->device_code); ?>" <?php echo e($selectedDevice && $selectedDevice->device_code == $dev->device_code ? 'selected' : ''); ?>>
                                🌿 <?php echo e($dev->nama_greenhouse); ?> (<?php echo e($dev->device_code); ?>) - <?php echo e($dev->lokasi); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option value="">Belum Ada Perangkat Terdaftar</option>
                        <?php endif; ?>
                    </select>
                </form>
            </div>
        </div>
    </div>

    <?php if($selectedDevice): ?>

    <div class="row g-3 mb-4">
        <div class="col-12">
            <div class="card card-custom p-3 bg-white shadow-sm">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                    <div class="fw-bold text-secondary">
                        <i class="fa-solid fa-sliders me-2"></i>Status Relay Aktuator saat ini:
                    </div>
                    <div class="d-flex gap-3 flex-wrap">
                        <div class="bg-light px-3 py-2 rounded-3 border d-flex align-items-center">
                            <i class="fa-solid fa-wind text-danger me-2"></i>
                            <span class="me-2 small fw-semibold">Kipas Exhaust:</span>
                            <span id="status-kipas" class="status-badge bg-secondary text-white">OFF</span>
                        </div>
                        <div class="bg-light px-3 py-2 rounded-3 border d-flex align-items-center">
                            <i class="fa-solid fa-droplet text-primary me-2"></i>
                            <span class="me-2 small fw-semibold">Pompa Air:</span>
                            <span id="status-pompa" class="status-badge bg-secondary text-white">OFF</span>
                        </div>
                        <div class="bg-light px-3 py-2 rounded-3 border d-flex align-items-center">
                            <i class="fa-solid fa-lightbulb text-warning me-2"></i>
                            <span class="me-2 small fw-semibold">Grow Light:</span>
                            <span id="status-lampu" class="status-badge bg-secondary text-white">OFF</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-12">
            <div class="card card-sensor bg-white border-start border-primary border-5 p-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted text-uppercase small mb-1">Status Baterai Aki (Solar Power) - <?php echo e($selectedDevice->device_code); ?></h6>
                        <div class="d-flex align-items-baseline gap-3">
                            <div class="sensor-value text-primary" id="val-battery-pct">
                                <?php echo e($latestData ? $latestData->persentase_baterai ?? 0 : '0'); ?><span class="fs-4">%</span>
                            </div>
                            <div class="fs-4 fw-bold text-secondary" id="val-battery-v">
                                (<?php echo e($latestData ? number_format($latestData->tegangan_baterai ?? 0, 2) : '0.00'); ?> V)
                            </div>
                        </div>
                    </div>
                    <i class="fa-solid fa-car-battery fa-3x text-primary opacity-25"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card card-sensor bg-white border-start border-danger border-5 p-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted text-uppercase small mb-1">Suhu Udara</h6>
                        <div class="sensor-value text-danger" id="val-suhu"><?php echo e($latestData ? number_format($latestData->suhu, 1) : '0.0'); ?> <span class="fs-4">°C</span></div>
                    </div>
                    <i class="fa-solid fa-temperature-high fa-3x text-danger opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-sensor bg-white border-start border-info border-5 p-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted text-uppercase small mb-1">Kelembaban Udara</h6>
                        <div class="sensor-value text-info" id="val-humidity"><?php echo e($latestData ? number_format($latestData->kelembaban_udara, 1) : '0.0'); ?> <span class="fs-4">%</span></div>
                    </div>
                    <i class="fa-solid fa-cloud-sun-rain fa-3x text-info opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-sensor bg-white border-start border-warning border-5 p-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted text-uppercase small mb-1">Intensitas Cahaya</h6>
                        <div class="sensor-value text-warning" id="val-lux"><?php echo e($latestData ? number_format($latestData->intensitas_cahaya, 0) : '0'); ?> <span class="fs-4"> Lux</span></div>
                    </div>
                    <i class="fa-solid fa-sun fa-3x text-warning opacity-25"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-md-6">
            <div class="card card-sensor bg-white border-start border-success border-5 p-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted text-uppercase small mb-1">Kelembaban Tanah (Pot 1)</h6>
                        <div class="sensor-value text-success" id="val-soil1"><?php echo e($latestData ? $latestData->kelembaban_tanah_1 : '0'); ?> <span class="fs-4">%</span></div>
                    </div>
                    <i class="fa-solid fa-seedling fa-3x text-success opacity-25"></i>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card card-sensor bg-white border-start border-success border-5 p-3">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted text-uppercase small mb-1">Kelembaban Tanah (Pot 2)</h6>
                        <div class="sensor-value text-success" id="val-soil2"><?php echo e($latestData ? $latestData->kelembaban_tanah_2 : '0'); ?> <span class="fs-4">%</span></div>
                    </div>
                    <i class="fa-solid fa-seedling fa-3x text-success opacity-25"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-12">
            <div class="card card-custom p-4 bg-white shadow-sm">
                <h5 class="fw-bold text-dark mb-3">
                    <i class="fa-solid fa-chart-area me-2 text-success"></i>Grafik Tren Parameter - <?php echo e($selectedDevice->nama_greenhouse); ?>

                </h5>
                <div style="position: relative; height:300px; width:100%">
                    <canvas id="greenhouseChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 mb-5">
        <div class="card-header bg-dark text-white fw-bold">
            <i class="fa-solid fa-clock-history me-2"></i> 10 Riwayat Terakhir (<?php echo e($selectedDevice->device_code); ?>)
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped table-hover mb-0" id="sensor-table">
                    <thead class="table-secondary">
                        <tr>
                            <th>Waktu Terbaca</th>
                            <th>Suhu (°C)</th>
                            <th>Kelembaban Udara (%)</th>
                            <th>Tanah Pot 1 (%)</th>
                            <th>Tanah Pot 2 (%)</th>
                            <th>Intensitas (Lux)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $historyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($row->created_at->format('H:i:s / d-M-Y')); ?></td>
                            <td><?php echo e($row->suhu); ?></td>
                            <td><?php echo e($row->kelembaban_udara); ?></td>
                            <td><?php echo e($row->kelembaban_tanah_1); ?>%</td>
                            <td><?php echo e($row->kelembaban_tanah_2); ?>%</td>
                            <td><?php echo e(number_format($row->intensitas_cahaya, 0)); ?> Lux</td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr id="empty-row"><td colspan="6" class="text-center text-muted">Belum ada data sensor untuk perangkat ini.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php else: ?>
    <div class="alert alert-warning text-center p-5 rounded-3">
        <h4><i class="fa-solid fa-triangle-exclamation me-2"></i>Belum Ada Perangkat Terdaftar</h4>
        <p>Silakan daftarkan perangkat ESP32 baru di database terlebih dahulu.</p>
    </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php if($selectedDevice): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Kode unik perangkat yang sedang aktif di layar pengguna saat ini
    const activeDeviceCode = "<?php echo e($selectedDevice->device_code); ?>";

    const initialData = <?php echo json_encode($historyData ? $historyData->reverse()->values() : [], 15, 512) ?>;
    
    // Nilai Threshold lokal
    const thSuhuOn   = parseFloat("<?php echo e(\App\Models\Threshold::where('device_id', $selectedDevice->id)->latest()->first()->batas_suhu_on ?? 33.0); ?>");
    const thSuhuOff  = parseFloat("<?php echo e(\App\Models\Threshold::where('device_id', $selectedDevice->id)->latest()->first()->batas_suhu_off ?? 31.0); ?>");
    const thTanahOn  = parseInt("<?php echo e(\App\Models\Threshold::where('device_id', $selectedDevice->id)->latest()->first()->batas_tanah_on ?? 55); ?>");
    const thTanahOff = parseInt("<?php echo e(\App\Models\Threshold::where('device_id', $selectedDevice->id)->latest()->first()->batas_tanah_off ?? 65); ?>");
    const thLuxOn    = parseFloat("<?php echo e(\App\Models\Threshold::where('device_id', $selectedDevice->id)->latest()->first()->batas_lux_on ?? 5000); ?>");
    const thLuxOff   = parseFloat("<?php echo e(\App\Models\Threshold::where('device_id', $selectedDevice->id)->latest()->first()->batas_lux_off ?? 7000); ?>");

    let labels = []; let suhuData = []; let humData = []; let soil1Data = [];

    if (initialData && initialData.length > 0) {
        labels = initialData.map(item => {
            const d = new Date(item.created_at);
            return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        });
        suhuData = initialData.map(item => item.suhu || 0);
        humData = initialData.map(item => item.kelembaban_udara || 0);
        soil1Data = initialData.map(item => item.kelembaban_tanah_1 || 0);
    }

    const ctx = document.getElementById('greenhouseChart').getContext('2d');
    const greenhouseChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                { label: 'Suhu (°C)', data: suhuData, borderColor: '#dc3545', backgroundColor: 'transparent', tension: 0.3, borderWidth: 3 },
                { label: 'Kelembaban Udara (%)', data: humData, borderColor: '#0dcaf0', backgroundColor: 'transparent', tension: 0.3, borderWidth: 3 },
                { label: 'Tanah Pot 1 (%)', data: soil1Data, borderColor: '#198754', backgroundColor: 'transparent', tension: 0.3, borderWidth: 2, borderDash: [5,5] }
            ]
        },
        options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: false } } }
    });

    function hitungStatusAktuator(suhu, tanah1, tanah2, lux) {
        const badgeKipas = document.getElementById('status-kipas');
        if (badgeKipas) {
            if (suhu >= thSuhuOn) { badgeKipas.innerHTML = 'ON'; badgeKipas.className = 'status-badge bg-success text-white'; }
            else if (suhu <= thSuhuOff) { badgeKipas.innerHTML = 'OFF'; badgeKipas.className = 'status-badge bg-danger text-white'; }
        }
        const badgePompa = document.getElementById('status-pompa');
        if (badgePompa) {
            if (tanah1 < thTanahOn || tanah2 < thTanahOn) { badgePompa.innerHTML = 'ON'; badgePompa.className = 'status-badge bg-success text-white'; }
            else if (tanah1 > thTanahOff && tanah2 > thTanahOff) { badgePompa.innerHTML = 'OFF'; badgePompa.className = 'status-badge bg-danger text-white'; }
        }
        const badgeLampu = document.getElementById('status-lampu');
        if (badgeLampu) {
            if (lux < thLuxOn) { badgeLampu.innerHTML = 'ON'; badgeLampu.className = 'status-badge bg-success text-white'; }
            else if (lux > thLuxOff) { badgeLampu.innerHTML = 'OFF'; badgeLampu.className = 'status-badge bg-danger text-white'; }
        }
    }

    if (initialData && initialData.length > 0) {
        const last = initialData[initialData.length - 1];
        hitungStatusAktuator(last.suhu, last.kelembaban_tanah_1, last.kelembaban_tanah_2, last.intensitas_cahaya);
    }

    // LISTENER PUSHER PINTAR (Hanya perbarui layar jika device_code cocok)
    const checkChannelReady = setInterval(() => {
        if (window.channel) {
            clearInterval(checkChannelReady);

            window.channel.bind('SensorEvent', function(data) {
                const sensor = data.sensorData;
                const incomingDeviceCode = data.deviceCode || (sensor ? sensor.device_code : null);

                // FILTRASI PUSHER: Cek apakah event ini milik perangkat yang sedang kita buka
                if (sensor && (incomingDeviceCode === activeDeviceCode)) {
                    document.getElementById('val-suhu').innerHTML = parseFloat(sensor.suhu).toFixed(1) + ' <span class="fs-4">°C</span>';
                    document.getElementById('val-humidity').innerHTML = parseFloat(sensor.kelembaban_udara).toFixed(1) + ' <span class="fs-4">%</span>';
                    document.getElementById('val-lux').innerHTML = parseFloat(sensor.intensitas_cahaya).toFixed(0) + ' <span class="fs-4"> Lux</span>';
                    document.getElementById('val-soil1').innerHTML = sensor.kelembaban_tanah_1 + ' <span class="fs-4">%</span>';
                    document.getElementById('val-soil2').innerHTML = sensor.kelembaban_tanah_2 + ' <span class="fs-4">%</span>';

                    if(document.getElementById('val-battery-pct')) {
                        document.getElementById('val-battery-pct').innerHTML = (sensor.persentase_baterai || 0) + ' <span class="fs-4">%</span>';
                    }
                    if(document.getElementById('val-battery-v')) {
                        document.getElementById('val-battery-v').innerHTML = '(' + parseFloat(sensor.tegangan_baterai || 0).toFixed(2) + ' V)';
                    }

                    hitungStatusAktuator(sensor.suhu, sensor.kelembaban_tanah_1, sensor.kelembaban_tanah_2, sensor.intensitas_cahaya);

                    const date = new Date(sensor.created_at || new Date());
                    const timeStr = date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                    
                    greenhouseChart.data.labels.push(timeStr);
                    greenhouseChart.data.datasets[0].data.push(sensor.suhu);
                    greenhouseChart.data.datasets[1].data.push(sensor.kelembaban_udara);
                    greenhouseChart.data.datasets[2].data.push(sensor.kelembaban_tanah_1);

                    if (greenhouseChart.data.labels.length > 10) {
                        greenhouseChart.data.labels.shift();
                        greenhouseChart.data.datasets[0].data.shift();
                        greenhouseChart.data.datasets[1].data.shift();
                        greenhouseChart.data.datasets[2].data.shift();
                    }
                    greenhouseChart.update();

                    const formattedTime = timeStr + ' / ' + date.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
                    const tableBody = document.querySelector('#sensor-table tbody');
                    if (tableBody) {
                        const emptyRow = document.getElementById('empty-row'); if (emptyRow) emptyRow.remove();
                        const newRow = document.createElement('tr');
                        newRow.innerHTML = `<td>${formattedTime}</td><td>${parseFloat(sensor.suhu).toFixed(1)}</td><td>${parseFloat(sensor.kelembaban_udara).toFixed(1)}</td><td>${sensor.kelembaban_tanah_1}%</td><td>${sensor.kelembaban_tanah_2}%</td><td>${parseFloat(sensor.intensitas_cahaya).toLocaleString('id-ID')} Lux</td>`;
                        tableBody.insertBefore(newRow, tableBody.firstChild);
                        if (tableBody.children.length > 10) tableBody.removeChild(tableBody.lastChild);
                    }
                }
            });
        }
    }, 200);
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\greenhouse-laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>